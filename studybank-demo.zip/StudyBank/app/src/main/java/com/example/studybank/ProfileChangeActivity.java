package com.example.studybank;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import com.firebase.client.Firebase;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Locale;
import java.util.SortedSet;
import java.util.TreeSet;

public class ProfileChangeActivity extends AppCompatActivity {

    private EditText editProgram;
    private EditText editName;
    private Spinner editYear;
//  private EditText editEmail;
    private Spinner editCountry;
    private EditText editClasses;
    private EditText editBio;

    private Button confirm;
    private Firebase rootRef;
    private FirebaseUser user;
    private DatabaseReference reference;
    private String userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        user = FirebaseAuth.getInstance().getCurrentUser();
        reference = FirebaseDatabase.getInstance().getReference("Users");
        userId = user.getUid();

        editProgram = findViewById(R.id.inputProgram);
//        final SharedPreferences prefProgram = getPreferences(MODE_PRIVATE);
//        String defaultProgram = prefProgram.getString("Program", "");
//        editProgram.setText(defaultProgram);

        editName = findViewById(R.id.inputName);
//        final SharedPreferences prefName = getPreferences(MODE_PRIVATE);
//        String defaultName = prefName.getString("Name", "");
//        editName.setText(defaultName);

        final Spinner spinner = (Spinner) findViewById(R.id.inputYear);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(ProfileChangeActivity.this,
                R.array.years, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        //editYear = findViewById(R.id.inputYear);
        final SharedPreferences prefYear = getPreferences(MODE_PRIVATE);
        int position = prefYear.getInt("Year",-1);
        spinner.setSelection(position);
        //EditText editYear = findViewById(R.id.inputYear);
        final String defaultYear = prefYear.getString("Year", "");
        //editYear.setText(defaultYear);

//        editEmail = findViewById(R.id.inputEmail);
//        final SharedPreferences prefEmail = getPreferences(MODE_PRIVATE);
//        String defaultEmail = prefEmail.getString("Email", "");
//        editEmail.setText(defaultEmail);

        final Spinner countryList = (Spinner)findViewById(R.id.inputCountry);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, getCountryListByLocale().toArray(new String[0]));
        countryList.setAdapter(adapter2);

        final SharedPreferences prefCountry = getPreferences(MODE_PRIVATE);
        int positionCountry = prefCountry.getInt("Country", -1);
        countryList.setSelection(positionCountry);
        //EditText editCountry = findViewById(R.id.inputCountry);
        //String defaultCountry = prefCountry.getString("Country", "");
        //editCountry.setText(defaultCountry);

        editClasses = findViewById(R.id.inputClasses);
//        final SharedPreferences prefClasses = getPreferences(MODE_PRIVATE);
//        String defaultClasses = prefClasses.getString("Classes", "");
//        editClasses.setText(defaultClasses);

        editBio = findViewById(R.id.inputBio);
//        final SharedPreferences prefBio = getPreferences(MODE_PRIVATE);
//        String defaultBio = prefBio.getString("Bio", "");
//        editBio.setText(defaultBio);

        reference.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                User userInfo = snapshot.getValue(User.class);
                if (userInfo != null) {
                    String strName = userInfo.name;
                    Log.d("name", strName);
                    editName.setText(strName);
                }

                if (snapshot.child("program").exists()) {
                    String strProgram = snapshot.child("program").getValue().toString();
                    Log.d("program", strProgram);
                    editProgram.setText(strProgram);
                }

                if (snapshot.child("bio").exists()) {
                    String strBio = snapshot.child("bio").getValue().toString();
                    Log.d("bio", strBio);
                    editBio.setText(strBio);
                }

                if (snapshot.child("classes").exists()) {
                    String strClasses = snapshot.child("classes").getValue().toString();
                    Log.d("classes", strClasses);
                    editClasses.setText(strClasses);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        confirm = findViewById(R.id.confirmButton);
        rootRef = new Firebase("https://studybank-43992.firebaseio.com/");

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                SharedPreferences.Editor editorName = prefName.edit();
//                EditText editName = findViewById(R.id.inputName);
//                editorName.putString("Name", editName.getText()+"");
//                editorName.commit();
//
//                SharedPreferences.Editor editorProgram = prefProgram.edit();
//                EditText editProgram = findViewById(R.id.inputProgram);
//                editorProgram.putString("Program", editProgram.getText()+"");
//                editorProgram.commit();
//
//                SharedPreferences.Editor editorYear = prefYear.edit();
//                int selectedPosition = spinner.getSelectedItemPosition();
//                editorYear.putInt("Year", selectedPosition);
//                editorYear.commit();
//                //SharedPreferences.Editor editorYear = prefYear.edit();
//                //EditText editYear = findViewById(R.id.inputYear);
//                //editorYear.putString("Year", editYear.getText()+"");
//                //editorYear.commit();
//
////                SharedPreferences.Editor editorEmail = prefEmail.edit();
////                EditText editEmail = findViewById(R.id.inputEmail);
////                editorEmail.putString("Email", editEmail.getText()+"");
////                editorEmail.commit();
//
//                SharedPreferences.Editor editorCountry = prefCountry.edit();
//                int selectedPosition2 = countryList.getSelectedItemPosition();
//                editorCountry.putInt("Country", selectedPosition2);
//                editorCountry.commit();
//                //EditText editCountry = findViewById(R.id.inputCountry);
//                //editorCountry.putString("Country", editCountry.getText()+"");
//                //editorCountry.commit();
//
//                SharedPreferences.Editor editorBio = prefBio.edit();
//                EditText editBio = findViewById(R.id.inputBio);
//                editorBio.putString("Bio", editBio.getText()+"");
//                editorBio.commit();
//
//                SharedPreferences.Editor editorClasses = prefClasses.edit();
//                EditText editClasses = findViewById(R.id.inputClasses);
//                editorClasses.putString("Classes", editClasses.getText()+"");
//                editorClasses.commit();

                String strProgram = editProgram.getText().toString().trim();
                if (strProgram.length() > 0) {
                    Firebase childRef = rootRef.child("Users").child(userId).child("program");
                    childRef.setValue(strProgram);
                }
//                else {
//                    rootRef.child("Users").child(userId).child("program").removeValue();
//                }

                String strName = editName.getText().toString().trim();
                if (strName.length() > 0) {
                    Firebase childRef = rootRef.child("Users").child(userId).child("name");
                    childRef.setValue(strName);
                }
//                else {
//                    rootRef.child("Users").child(userId).child("name").removeValue();
//                }

//                String strEmail = editEmail.getText().toString().trim();
//                if (strEmail.length() > 0) {
//                    Firebase childRef = rootRef.child("Users").child(userId).child("email");
//                    childRef.setValue(strEmail);
//                }
//                else {
//                    rootRef.child("Users").child(userId).child("email").removeValue();
//                }

                String strBio = editBio.getText().toString().trim();
                if (strBio.length() > 0) {
                    Firebase childRef = rootRef.child("Users").child(userId).child("bio");
                    childRef.setValue(strBio);
                }
//                else {
//                    rootRef.child("Users").child(userId).child("bio").removeValue();
//                }

                String strClasses = editClasses.getText().toString().trim();
                if (strClasses.length() > 0) {
                    Firebase childRef = rootRef.child("Users").child(userId).child("classes");
                    childRef.setValue(strClasses);
                }
//                else {
//                    rootRef.child("Users").child(userId).child("classes").removeValue();
//                }

//                String strYear = editYear.getSelectedItem().toString();
//                Log.d("year", defaultYear);
//                if (strYear.length() > 0) {
//                    Firebase childRef = rootRef.child("Users").child(userId).child("year");
//                    childRef.setValue(strYear);
//                }
//                else {
//                    rootRef.child("Users").child(userId).child("year").removeValue();
//                }

//                String strCountry = editCountry.getSelectedItem().toString();
//                if (strCountry.length() > 0) {
//                    Firebase childRef = rootRef.child("Users").child(userId).child("country");
//                    childRef.setValue(strCountry);
//                }
//                else {
//                    rootRef.child("Users").child(userId).child("country").removeValue();
//                }

                Intent intent = new Intent(ProfileChangeActivity.this, ProfileMainActivity.class);
                startActivity(intent);

            }

        });

    }

    private SortedSet<String> getCountryListByLocale() {
        SortedSet<String> countries = new TreeSet<>();
        for (Locale locale : Locale.getAvailableLocales()) {
            if (!TextUtils.isEmpty(locale.getDisplayCountry())) {
                countries.add(locale.getDisplayCountry());
            }
        }
        return countries;
    }


}
