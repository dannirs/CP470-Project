package com.example.studybank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    Button btnLogin;
    EditText username;
    EditText password;
    //FirebaseAuth mAuth;
    Button btnRegister;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        btnRegister = findViewById(R.id.registerBtn);
        btnLogin = findViewById(R.id.loginBtn);

        sharedPreferences = getSharedPreferences("loginref",MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void onClickLogin(View view) {

        if (username.length()>0 && password.length()>0) {
            logIn();

            // Temporary return to homepage
            finish();
        } else {
            Toast toast_2 = Toast.makeText(getApplicationContext(), "Please enter username and/or password",Toast.LENGTH_SHORT);
            toast_2.show();
        }

    }

    public void logIn() {
        //Intent myIntent = new Intent(this, **CLASS GOES HERE**.class);
        //this.startActivity(myIntent);
    }
    public void onClickRegister(View view) {

        Intent myIntent = new Intent(this, RegisterActivity.class);
        this.startActivity(myIntent);


        //will open up new activity that ask for user information and adds it to the firebase
    }
}
