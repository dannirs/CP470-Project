package com.example.studybank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.graphics.Color.RED;
import static android.graphics.Color.WHITE;

public class RegisterActivity extends AppCompatActivity {


    Button btnBack;
    EditText username;
    EditText email;
    EditText password;
    EditText confirmpassword;
    //FirebaseAuth mAuth;
    Button btnRegister;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = findViewById(R.id.c_username);
        email = findViewById(R.id.c_email);
        password = findViewById(R.id.c_password);
        confirmpassword = findViewById(R.id.c_confirm);
        btnRegister = findViewById(R.id.regbtn);
        btnBack = findViewById(R.id.btnback);

    }

    public void onClickBack(View view) {

        Intent myIntent = new Intent(this, LoginActivity.class);
        this.startActivity(myIntent);

    }

    public void onClickRegister(View view) {

        if (username.length()>0 && email.length()>0 && password.length()>0 && confirmpassword.length()>0 && confirmpassword.getText() == password.getText()) {
            // goes to next activity
        } else {

            Toast toast_2 = Toast.makeText(getApplicationContext(), "Please fill in the highlighted areas.",Toast.LENGTH_SHORT);
            toast_2.show();

            errors();
        }


    }

    public void errors() {
        if (username.length()==0) {
            username.setBackgroundColor(RED);
        } else {
            username.setBackgroundColor(WHITE);
        }
        if (email.length()==0) {
            email.setBackgroundColor(RED);
        } else {
            email.setBackgroundColor(WHITE);
        }
        if (password.length()==0 || confirmpassword.length()==0 || confirmpassword.getText() != password.getText()) {
            password.setBackgroundColor(RED);
            confirmpassword.setBackgroundColor(RED);
        } else {
            password.setBackgroundColor(WHITE);
            confirmpassword.setBackgroundColor(WHITE);
        }

    }
}