package com.example.studybank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.Locale;
import java.util.SortedSet;
import java.util.TreeSet;

public class ProfileChangeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        final SharedPreferences prefName = getPreferences(MODE_PRIVATE);
        EditText editName = findViewById(R.id.inputName);
        String defaultName = prefName.getString("Name", "");
        editName.setText(defaultName);

        final SharedPreferences prefProgram = getPreferences(MODE_PRIVATE);
        EditText editProgram = findViewById(R.id.inputProgram);
        String defaultProgram = prefProgram.getString("Program", "");
        editProgram.setText(defaultProgram);

        final Spinner spinner = (Spinner) findViewById(R.id.inputYear);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(ProfileChangeActivity.this,
                R.array.years, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        final Spinner countryList = (Spinner)findViewById(R.id.inputCountry);
        ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, getCountryListByLocale().toArray(new String[0]));
        countryList.setAdapter(adapter2);

        final SharedPreferences prefYear = getPreferences(MODE_PRIVATE);
        int position = prefYear.getInt("Year",-1);
        spinner.setSelection(position);
        //EditText editYear = findViewById(R.id.inputYear);
        //String defaultYear = prefYear.getString("Year", "");
        //editYear.setText(defaultYear);

        final SharedPreferences prefEmail = getPreferences(MODE_PRIVATE);
        EditText editEmail = findViewById(R.id.inputEmail);
        String defaultEmail = prefEmail.getString("Email", "");
        editEmail.setText(defaultEmail);

        final SharedPreferences prefCountry = getPreferences(MODE_PRIVATE);
        int positionCountry = prefCountry.getInt("Country", -1);
        countryList.setSelection(positionCountry);
        //EditText editCountry = findViewById(R.id.inputCountry);
        //String defaultCountry = prefCountry.getString("Country", "");
        //editCountry.setText(defaultCountry);

        final SharedPreferences prefBio = getPreferences(MODE_PRIVATE);
        EditText editBio = findViewById(R.id.inputBio);
        String defaultBio = prefBio.getString("Bio", "");
        editBio.setText(defaultBio);

        final SharedPreferences prefClasses = getPreferences(MODE_PRIVATE);
        EditText editClasses = findViewById(R.id.inputClasses);
        String defaultClasses = prefClasses.getString("Classes", "");
        editClasses.setText(defaultClasses);

        final Button button = findViewById(R.id.confirmButton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // write to shared preferences
                SharedPreferences.Editor editorName = prefName.edit();
                EditText editName = findViewById(R.id.inputName);
                editorName.putString("Name", editName.getText()+"");
                editorName.commit();

                SharedPreferences.Editor editorProgram = prefProgram.edit();
                EditText editProgram = findViewById(R.id.inputProgram);
                editorProgram.putString("Program", editProgram.getText()+"");
                editorProgram.commit();

                SharedPreferences.Editor editorYear = prefYear.edit();
                int selectedPosition = spinner.getSelectedItemPosition();
                editorYear.putInt("Year", selectedPosition);
                editorYear.commit();
                //SharedPreferences.Editor editorYear = prefYear.edit();
                //EditText editYear = findViewById(R.id.inputYear);
                //editorYear.putString("Year", editYear.getText()+"");
                //editorYear.commit();

                SharedPreferences.Editor editorEmail = prefEmail.edit();
                EditText editEmail = findViewById(R.id.inputEmail);
                editorEmail.putString("Email", editEmail.getText()+"");
                editorEmail.commit();

                SharedPreferences.Editor editorCountry = prefCountry.edit();
                int selectedPosition2 = countryList.getSelectedItemPosition();
                editorCountry.putInt("Country", selectedPosition2);
                editorCountry.commit();
                //EditText editCountry = findViewById(R.id.inputCountry);
                //editorCountry.putString("Country", editCountry.getText()+"");
                //editorCountry.commit();

                SharedPreferences.Editor editorBio = prefBio.edit();
                EditText editBio = findViewById(R.id.inputBio);
                editorBio.putString("Bio", editBio.getText()+"");
                editorBio.commit();

                SharedPreferences.Editor editorClasses = prefClasses.edit();
                EditText editClasses = findViewById(R.id.inputClasses);
                editorClasses.putString("Classes", editClasses.getText()+"");
                editorClasses.commit();

                Intent intent = new Intent(ProfileChangeActivity.this, ProfileMainActivity.class);
                startActivity(intent);
            }
        });

    }

    private SortedSet<String> getCountryListByLocale() {
        SortedSet<String> countries = new TreeSet<>();
        for (Locale locale : Locale.getAvailableLocales()) {
            if (!TextUtils.isEmpty(locale.getDisplayCountry())) {
                countries.add(locale.getDisplayCountry());
            }
        }
        return countries;
    }


}
