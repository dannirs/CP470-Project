package com.example.studybank;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Locale;
import java.util.SortedSet;
import java.util.TreeSet;

public class ProfileMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPrefName = getSharedPreferences("ProfileChangeActivity", MODE_PRIVATE);
        String valueName = sharedPrefName.getString("Name", "");
        final TextView name = findViewById(R.id.name);
        if (valueName == "") {
            name.setText("User Name");
        }
        else {
            name.setText(valueName);
        }

        SharedPreferences sharedPrefProgram = getSharedPreferences("ProfileChangeActivity", MODE_PRIVATE);
        String valueProgram = sharedPrefProgram.getString("Program", "");

        SharedPreferences sharedPrefYear = getSharedPreferences("ProfileChangeActivity", MODE_PRIVATE);
        int valueYear = sharedPrefYear.getInt("Year", -1);
        final TextView program = findViewById(R.id.program);

        if (valueYear == -1 && valueProgram != "") {
            program.setText(valueProgram);
        }
        else if (valueProgram == "" && valueYear != -1) {
            String[] yearsList = getResources().getStringArray(R.array.years);
            String year = yearsList[valueYear];
            program.setText("Year " + year);
        }
        else if (valueProgram != "" && valueYear != -1){
            String[] yearsList = getResources().getStringArray(R.array.years);
            String year = yearsList[valueYear];
            program.setText(valueProgram + ", Year " + year);
        }
        else if (valueProgram == "" && valueYear == -1) {
            program.setText("Program, Year");
        }

        SharedPreferences sharedPrefEmail = getSharedPreferences("ProfileChangeActivity", MODE_PRIVATE);
        String valueEmail = sharedPrefEmail.getString("Email", "");
        final TextView email = findViewById(R.id.email);
        if (valueEmail == "") {
            email.setText("email@domain.com");
        }
        else {
            email.setText(valueEmail);
        }

        SharedPreferences sharedPrefCountry = getSharedPreferences("ProfileChangeActivity", MODE_PRIVATE);
        int valueCountry = sharedPrefCountry.getInt("Country", -1);
        final TextView country = findViewById(R.id.country);
        if (valueCountry != -1) {
            String[] countries = getCountryListByLocale().toArray(new String[0]);
            country.setText(countries[valueCountry]);
        }
        else {
            country.setText("Country");
        }

        SharedPreferences sharedPrefBio = getSharedPreferences("ProfileChangeActivity", MODE_PRIVATE);
        String valueBio = sharedPrefBio.getString("Bio", "");
        final TextView bio = findViewById(R.id.bio);
        if (valueBio == "") {
            bio.setText("I'm a student who loves to learn!");
        }
        else {
            bio.setText(valueBio);
        }

        SharedPreferences sharedPrefClasses = getSharedPreferences("ProfileChangeActivity", MODE_PRIVATE);
        String valueClasses = sharedPrefClasses.getString("Classes", "");
        final TextView classes = findViewById(R.id.classes);
        classes.setText(valueClasses);

        final Button button = findViewById(R.id.button);
        // when the user clicks the button in MainActivity:
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(ProfileMainActivity.this, ProfileChangeActivity.class);
                startActivity(intent);
            }
        });
    }

    public void userScore(View v){
        Intent intent = new Intent(ProfileMainActivity.this, ProfileChangeActivity.class);
        startActivity(intent);
    }

    public void friendsList(View v) {
        Intent intent = new Intent(ProfileMainActivity.this, ProfileChangeActivity.class);
        startActivity(intent);
    }

    public void library(View v) {
        Intent intent = new Intent(ProfileMainActivity.this, ProfileChangeActivity.class);
        startActivity(intent);
    }

    private SortedSet<String> getCountryListByLocale() {
        SortedSet<String> countries = new TreeSet<>();
        for (Locale locale : Locale.getAvailableLocales()) {
            if (!TextUtils.isEmpty(locale.getDisplayCountry())) {
                countries.add(locale.getDisplayCountry());
            }
        }
        return countries;
    }
}